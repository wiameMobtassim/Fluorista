<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '/R% 2T08>QA-]UQzY+l2RPIANsajV-z{2lpT8h:X}wGrNk{ipoeuXMD-dB3+$rT#' );
define( 'SECURE_AUTH_KEY',   'lH5VK=+`mk:qn9,MS8<>J7qy{1V&_>POqRDwBkX.8^9ifu(feU#nF1kKRmW7X_3B' );
define( 'LOGGED_IN_KEY',     '^KO~y-zkd@fpRqX/2T*P{2PN<f0y#ru(bVcW4d!&XhVBuH[7GlbJ:Ckt-,aLsN4?' );
define( 'NONCE_KEY',         'X`qrb;2w(0SM%60JX9ee`lCA,HLacBQK<i~f2wt7k?^vF/_ZNBr-EQ?fDFbA=P$w' );
define( 'AUTH_SALT',         ',nLjgW6d]NK~HU=Qeu@gQ(qggbbq!gDD*rS#58*Oa:xRXhO=b=@0)x/Np46S#/*q' );
define( 'SECURE_AUTH_SALT',  'x.tbO5Jq_sn1!Tx`2>&:@iKeW8s~U(OJ;zS~2FdyNSb3a3V(k5GG&~LtTq?P=Y/y' );
define( 'LOGGED_IN_SALT',    'ZHu^;cHT-3OFcr;$mC:P]ahv3>o 9woP*YfE:27G_!ips<|*y]VR:J}g^ib^O!0w' );
define( 'NONCE_SALT',        'yl`?kV4YV=vCNMO:_PL3*03qTeZXp4(y2wuEl|6a7ZgI+B5JsW&R39tys:5Fc?AE' );
define( 'WP_CACHE_KEY_SALT', '7rny3:BT#8tHhL?xvA$6~<,oRnu_X86gTqS/3S0Err<{s?-[?Ni8^9[2^n^E!SeZ' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
